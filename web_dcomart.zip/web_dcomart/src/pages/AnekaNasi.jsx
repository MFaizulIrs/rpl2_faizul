import { useState } from "react";

const anekanasi = () => {
  const [orders, setOrders] = useState([0, 0, 0, 0]); // State untuk jumlah pesanan
  const [showCartButton, setShowCartButton] = useState(false); // State untuk menampilkan tombol "Tambah ke Keranjang"

  // Fungsi untuk menambah pesanan
  const addOrder = (index) => {
    const newOrders = [...orders];
    newOrders[index] += 1;
    setOrders(newOrders);
    setShowCartButton(true); // Tampilkan tombol jika ada pesanan
  };

  // Fungsi untuk mengurangi pesanan
  const removeOrder = (index) => {
    const newOrders = [...orders];
    if (newOrders[index] > 0) {
      newOrders[index] -= 1;
      setOrders(newOrders);
    }

    // Periksa jika semua pesanan menjadi 0
    if (newOrders.every((count) => count === 0)) {
      setShowCartButton(false); // Sembunyikan tombol
    }
  };

  // Fungsi untuk menghapus tombol setelah klik "Tambah ke Keranjang"
  const handleCartClick = () => {
    alert("Pesanan ditambahkan ke keranjang!");
    setShowCartButton(false);
    setOrders([0, 0, 0, 0]); // Reset pesanan ke 0
  };

  return (
    <section className="p-6 bg-[#E4F4FD] h-[90vh] w-full font-poppins">
      {/* Breadcrumb */}
      <div className="flex items-center px-12 py-3 mb-3">
        <button className="bg-white border border-gray-300 rounded-full h-10 w-10 flex items-center justify-center shadow-md mr-3">
          <img
            src="src/assets/icon_back_navy.png"
            alt="Back"
            className="h-5 w-5"
          />
        </button>
        <div className="bg-white border border-gray-300 rounded-2xl h-14 w-[250px] flex items-center justify-center shadow-md px-4 gap-2">
          <img
            src="src/assets/icon_nasgor.png"
            alt="Category"
            className="h-12 w-12"
          />
          <span className="text-sm font-bold text-[#083c5a]">
            Semua Produk UMKM
          </span>
        </div>
      </div>

      {/* Products */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 px-12">
        {[
          {
            img: "src/assets/umkm_nasi uduk.jpg",
            title: "Nasi Uduk Bowl",
            resto: "Bakul Mak Entiek",
            price: "Rp 17.000",
            sold: "10 terjual",
          },
          {
            img: "src/assets/umkm_nasi goreng.png",
            title: "Nasi Goreng Spesial",
            resto: "Warung Bu Nenik",
            price: "Rp 20.000",
            sold: "20 terjual",
          },
          {
            img: "src/assets/umkm_nasi kuning.png",
            title: "Nasi Kuning Lengkap",
            resto: "Sutil Sederhana",
            price: "Rp 21.000",
            sold: "10 terjual",
          },
          {
            img: "src/assets/umkm_nasgor sosis.png",
            title: "Nasi Goreng Sosis",
            resto: "Dapur Bapak",
            price: "Rp 20.000",
            sold: "11 terjual",
          },
        ].map((product, index) => (
          <div
            key={index}
            className="bg-white border border-gray-300 rounded-xl shadow-md overflow-hidden relative"
          >
            <img
              src={product.img}
              alt={product.title}
              className="w-full h-44 object-cover mt-3 rounded-md"
            />
            <h3 className="text-lg font-bold text-[#083c5a] text-left px-4 mt-2">
              {product.title}
            </h3>
            <p className="text-sm text-[#083c5a] text-left px-4">
              {product.resto}
            </p>
            <div className="flex justify-between items-center px-4 mt-2 mb-4">
              <p className="text-green-600 font-bold">{product.price}</p>
              <span className="text-sm text-[#083c5a]">{product.sold}</span>
            </div>
            <div className="absolute bottom-10 right-4 flex items-center gap-4 bg-yellow-400 px-4 py-2 rounded-full">
              {/* Kondisi agar tombol minus hanya muncul jika jumlah pesanan lebih dari 0 */}
              {orders[index] > 0 && (
                <button
                  onClick={() => removeOrder(index)}
                  className="text-[#083c5a] font-bold"
                >
                  -
                </button>
              )}
              {/* Kondisi untuk menampilkan jumlah barang hanya jika pesanan lebih dari 0 */}
              {orders[index] > 0 && (
                <span className="text-[#083c5a] font-bold">
                  {orders[index]}
                </span>
              )}
              <button
                onClick={() => addOrder(index)}
                className="text-[#083c5a] font-bold"
              >
                +
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Tambah ke Keranjang Button */}
      {showCartButton && (
        <button
          className="fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-[#083c5a] font-bold py-3 px-6 rounded-lg shadow-lg"
          onClick={handleCartClick}
        >
          Tambah ke Keranjang
        </button>
      )}
    </section>
  );
};

export default anekanasi;
