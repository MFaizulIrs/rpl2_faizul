import React from "react";

const DimSum = () => {
  return (
    <section className="bg-[#E4F4FD] h-[86vh] w-full font-poppins">
      {/* Breadcrumb */}
      <div className="flex items-center px-12 py-3 mb-3">
        <button className="bg-white border border-gray-300 rounded-full h-10 w-10 flex items-center justify-center shadow-md mr-3">
          <img
            src="src\assets\icon_back_navy.png"
            alt="Back"
            className="h-5 w-5"
          />
        </button>
        <div className="bg-white border border-gray-300 rounded-2xl h-14 w-[250px] flex items-center justify-center shadow-md px-4 gap-2">
          <img
            src="src\assets\icon_nasgor.png"
            alt="Category"
            className="h-12 w-12"
          />
          <span className="text-sm font-bold text-[#083c5a]">
            OyOy
          </span>
        </div>
      </div>

      {/* Categories */}
      <div className="px-12 mb-8">
        <div className="flex gap-3">
          <button className="px-5 py-2 bg-yellow-400 text-[#083c5a] rounded-full font-bold">
            Aneka Nasi
          </button>
          <div className="flex gap-3">
            <button
              className="px-5 py-2 bg-white border border-gray-300 text-[#083c5a] rounded-full font-bold"
              onClick={() => (window.location.href = "dimsum.js")}
            >
              Dimsum
            </button>
            <button className="px-5 py-2 bg-white border border-gray-300 text-[#083c5a] rounded-full font-bold">
              Kue Tradisional
            </button>
            <button className="px-5 py-2 bg-white border border-gray-300 text-[#083c5a] rounded-full font-bold">
              Jajanan Manis
            </button>
          </div>
        </div>
      </div>

      {/* Products */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 px-12">
        {[
          {
            img: "src/assets/umkm_nasi uduk.jpg",
            title: "Nasi Uduk Bowl",
            resto: "Bakul Mak Entiek",
            price: "Rp 17.000",
            sold: "10 terjual",
          },
          {
            img: "src/assets/umkm_nasi goreng.png",
            title: "Nasi Goreng Spesial",
            resto: "Warung Bu Nenik",
            price: "Rp 20.000",
            sold: "20 terjual",
          },
          {
            img: "src/assets/umkm_nasi kuning.png",
            title: "Nasi Kuning Lengkap",
            resto: "Sutil Sederhana",
            price: "Rp 21.000",
            sold: "10 terjual",
          },
          {
            img: "src/assets/umkm_nasgor sosis.png",
            title: "Nasi Goreng Sosis",
            resto: "Dapur Bapak",
            price: "Rp 20.000",
            sold: "11 terjual",
          },
        ].map((product, index) => (
          <div
            key={index}
            className="bg-white border border-gray-300 rounded-xl shadow-md overflow-hidden relative"
          >
            <img
              src={product.img}
              alt={product.title}
              className="w-full h-44 object-cover mt-3 rounded-md"
            />
            <h3 className="text-lg font-bold text-[#083c5a] text-left px-4 mt-2">
              {product.title}
            </h3>
            <p className="text-sm text-[#083c5a] text-left px-4">
              {product.resto}
            </p>
            <div className="flex justify-between items-center px-4 mt-2 mb-4">
              <p className="text-green-600 font-bold">{product.price}</p>
              <span className="text-sm text-[#083c5a]">{product.sold}</span>
            </div>
            <button className="bg-yellow-400 text-[#083c5a] rounded-full w-10 h-10 absolute bottom-10 right-4 flex items-center justify-center">
              +
            </button>
          </div>
        ))}
      </div>
    </section>
  );
};

export default DimSum;
