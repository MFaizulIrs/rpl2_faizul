import React, { useState } from "react";

const DeskNasgorSosis = () => {
  const [quantity, setQuantity] = useState(0);

  const increaseQuantity = () => {
    setQuantity(quantity + 1);
  };

  const decreaseQuantity = () => {
    if (quantity > 0) {
      setQuantity(quantity - 1);
    }
  };

  return (
    <section className="p-6 bg-[#E4F4FD] h-[90vh] w-full font-poppins">
      {/* Breadcrumb */}
      <div className="flex items-center px-12 py-3 mb-3">
        <button className="bg-white border border-gray-300 rounded-full h-10 w-10 flex items-center justify-center shadow-md mr-3">
          <img
            src="src/assets/icon_back_navy.png"
            alt="Back"
            className="h-5 w-5"
          />
        </button>
        <div className="bg-white border border-gray-300 rounded-2xl h-14 w-[250px] flex items-center justify-center shadow-md px-4 gap-2">
          <img
            src="src/assets/icon_nasgor.png"
            alt="Category"
            className="h-12 w-12"
          />
          <span className="text-sm font-bold text-[#083c5a]">
            Semua Produk UMKM
          </span>
        </div>
      </div>

      {/* Produk Deskripsi */}
      <div className="flex flex-wrap lg:flex-nowrap gap-[150px]">
        {/* Gambar Produk + Detail Produk */}
        <div className="flex flex-col items-start">
          <img
            src="src\assets\umkm_nasgor sosis.png"
            alt="Nasgor Sosis"
            style={{ marginLeft: "100px" }} // Gambar bergeser 20px ke kanan
            className="w-full lg:w-[550px] h-[350px] object-cover rounded-xl shadow-md border-2 border-gray-300 mb-4"
          />

          <div className="mt-4 flex items-center w-full ml-[100px]">
            <p className="text-3xl font-bold text-[#083c5a]">
              Getuk Lindri Manis
            </p>
            <span
              className="text-base text-[#083c5a]"
              style={{ marginLeft: "215px" }}
            >
              10 terjual
            </span>
          </div>

          <p className="text-lg text-[#083c5a] mt-1 ml-[100px]">
            Ayu's Kitchen
          </p>
          <p className="text-2xl font-bold text-green-600 ml-[100px]">
            Rp 15.000
          </p>
        </div>

        {/* Deskripsi Produk */}
        <div className="flex flex-col bg-white border border-gray-300 rounded-2xl shadow-md h-[200px] w-[600px] overflow-y-auto p-4 mr-[100px]">
          <div className="flex flex-col mb-2">
            <p className="text-xl font-bold text-[#083c5a]">Stok</p>
            <span className="text-md text-[#083c5a]">30</span>
          </div>
          <p className="text-xl font-bold text-[#083c5a] mb-2">Deskripsi</p>
          <p className="text-md text-[#083c5a]">
            Getuk lindri memiliki rasa manis lembut dengan aroma khas singkong
            dan sedikit gurih dari taburan kelapa parut.
          </p>
        </div>
      </div>

      {/* Kontrol Jumlah */}
      <div className="flex justify-center mt-6 gap-4 ml-[700px] mt-[-200px]">
        <div className="flex items-center bg-yellow-400 border border-gray-300 rounded-2xl h-12 px-4 shadow-md cursor-pointer gap-4">
          <button onClick={decreaseQuantity}>
            <img src="src\assets\icon_minus_navy.png" alt="Kurang" className="h-6 w-6" />
          </button>
          <span className="text-lg font-bold">{quantity}</span>
          <button onClick={increaseQuantity}>
            <img
              src="src\assets\icon_plus_navy.png"
              alt="Tambah"
              className="h-6 w-6"
            />
          </button>
        </div>
      </div>

      {/* Tombol Masukkan Keranjang */}
      <div className="flex justify-center mt-6 ml-[700px]">
        <button
          className={`bg-yellow-400 text-[#083c5a] font-bold py-3 px-8 rounded-2xl shadow-lg ${
            quantity === 0 ? "opacity-50 cursor-not-allowed" : ""
          }`}
          disabled={quantity === 0}
        >
          Tambah ke Keranjang
        </button>
      </div>
    </section>
  );
};

export default DeskNasgorSosis;
