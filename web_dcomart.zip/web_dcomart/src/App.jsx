import Navbar from "./components/navbar";
import Footer from "./components/footer";
import AnekaNasi from "./pages/anekanasi";
import DeskNasgorSosis from "./pages/DeskNasgorSosis";

export default function App() {
  return (
    <div>
      {/* Navbar */}
      <Navbar />

      {/* content */}
      {/* <AnekaNasi /> */} 
      <DeskNasgorSosis />

      {/* Footer */}
      {/* <Footer /> */}
    </div>
  );
}
