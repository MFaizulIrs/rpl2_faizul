const navbar = () => {
  return (
    <header className="bg-[#fcc72c] rounded-b-lg flex justify-between items-center p-2.5 px-12 shadow-md w-full box-border">
      {/* Logo */}
      <div className="flex items-center cursor-pointer mr-64 gap-2.5">
        <img
          src="src\assets\Dco Mart Logo.png"
          alt="img-dcomart"
          className="h-12 object-contain"
        />
        <p className="font-poppins text-lg font-bold text-[#083c5a] m-0 whitespace-nowrap">
          d'Co Mart Online Shop
        </p>
      </div>

      {/* Navigation */}
      <nav className="flex gap-5">
        <div
          className="bg-[#e4f4fd] border border-[#bebebe] rounded-full h-12 w-24 flex items-center justify-center gap-1.25 shadow-md cursor-pointer hover:bg-[#d1e9f7] transition-all"
          onClick={() => alert("Keranjang clicked!")} // Example onClick function
        >
          <img
            src="src/assets/icon_chart_navy.png"
            alt="keranjang-belanja"
            className="h-8 w-8 object-contain"
          />
          <span className="font-poppins text-lg font-bold text-[#083c5a]">
            0
          </span>
        </div>

        <div
          className="flex items-center cursor-pointer gap-2"
          onClick={() => (window.location.href = "/beranda")}
        >
          <img
            src="src\assets\icon_search_blue.png"
            alt="search-navbar"
            className="h-6 w-6 object-contain"
          />
          <p className="font-poppins text-lg font-bold text-[#e4f4fd] m-0 whitespace-nowrap">
            Cari
          </p>
        </div>

        <div className="flex items-center cursor-pointer gap-2">
          <img
            src="src\assets\icon_home_blue.png"
            alt="homepage-navbar"
            className="h-6 w-6 object-contain"
          />
          <p className="font-poppins text-lg font-bold text-[#e4f4fd] m-0 whitespace-nowrap">
            Beranda
          </p>
        </div>

        <div className="flex items-center cursor-pointer gap-2">
          <img
            src="src\assets\icon_act_blue.png"
            alt="activity-navbar"
            className="h-6 w-6 object-contain"
          />
          <p className="font-poppins text-lg font-bold text-[#e4f4fd] m-0 whitespace-nowrap">
            Aktivitas
          </p>
        </div>

        <div className="flex items-center cursor-pointer gap-2">
          <img
            src="src\assets\icon_profile_blue.png"
            alt="person-navbar"
            className="h-6 w-6 object-contain"
          />
          <p className="font-poppins text-lg font-bold text-[#e4f4fd] m-0 whitespace-nowrap">
            Saya
          </p>
        </div>
      </nav>
    </header>
  );
};

export default navbar;
